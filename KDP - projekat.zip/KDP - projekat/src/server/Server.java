package server;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.MalformedURLException;




import java.net.UnknownHostException;

import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import javax.swing.JLabel;



import client.Client;
import client.ClientInfo;
import client.ClientInfoIF;
import misc.Bid;
import misc.Item;
import misc.Item;
import misc.Message;
import subserver.Subserver;
import subserver.SubserverIF;
import subserver.SubserverInfo;
import subserver.SubserverInfoIF;

public class Server extends UnicastRemoteObject implements ServerIF, Runnable {
	private static final long serialVersionUID = 1L;
	public static final int DefaultPort = 4001;
	private static long IDSub=0;
	private static long IDCli=0;
	private static long IDItem=0;
	public long x;
	public long y;
	public long z;
	public long t;
	private String serverURL;
	private int port;
	private LinkedList<SubserverInfo> subservers = new LinkedList<>();
	private LinkedList<SubserverInfo> activeSubs = new LinkedList<>();
	private LinkedList<ClientInfo> clients = new LinkedList<>();
	private LinkedList<Item> items = new LinkedList<>();
	private LinkedList<Item> waiting = new LinkedList<>();
	private Log log = new Log("server.log", this);
	private volatile boolean theEND = false;
	private Thread myThread = null;
	private String urlString = null;
	public ServerGUI gui;
	private Sender sender;
	private MyComparator comp = new MyComparator();
	
	class MyComparator implements Comparator<SubserverInfo> {
		@Override
		public int compare(SubserverInfo s1, SubserverInfo s2) {
			try {
				if(s1.getSubserver().getNumOfItems() < s2.getSubserver().getNumOfItems()){
				    return -1;
				} else {
				    return 1;
				}
			} catch (RemoteException e) {
				e.printStackTrace();
			}
			return 0;
		}
	}
	
	public Server(ServerGUI gui) throws Exception {
		this(java.net.InetAddress.getLocalHost().getHostAddress(), DefaultPort, gui);
	}
	
	private Server(String serverURL, int port, ServerGUI gui) throws RemoteException {
		this.serverURL = serverURL;
		this.port = port;
		this.gui = gui;
	}
	
	public Server(int port, ServerGUI gui) throws Exception {
		this(java.net.InetAddress.getLocalHost().getHostAddress(), port, gui);
	}
	
	public void start () {
		if (myThread == null){
			myThread = new Thread(this, "Server");
			myThread.start();
		}
	}
	
	public void setTimeParameters(long x, long y, long z, long t) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.t = t;
	}
	
	private void saveSoldItems() {
		File file = new File("SoldItems.txt");
		if (file.exists()) file.delete();
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));
			for(int i=0;i<clients.size();i++) {
				LinkedList<Item> itemsList = clients.get(i).getBoughtItems();
				for (int j = 0; j < itemsList.size(); j++) {
					Item item = itemsList.get(j);
					out.write("|ITEM: " + item.toString() + " |SELLER: " + item.getSeller().Description() + " |BUYER: " + clients.get(i).Description());
					out.newLine();
				}
			}
			out.flush();
			out.close();
		} catch (Exception e) {
		}
	}
	
	public void raiseServer(boolean flag) {
		System.setSecurityManager(new RMISecurityManager());
		try {
			gui.status.setText("Making Connection...");
			if (flag) LocateRegistry.createRegistry(port);
			log.append("Definisan Registry port");
			log.append("ServerImpl: kreira Server");
			urlString = "//" + serverURL + ":" + port + "/Server";
			log.append("ServerImpl: povezuje ga sa imenom : "+ urlString);
			Naming.rebind(urlString, this);
			log.append("Server je sada spreman.");
			sender = new Sender(this,items);
			sender.start();
			gui.status.setText("Connected with name " + urlString);
		} catch (Exception ex) { 
			System.out.println("Error occured" + ex); ex.printStackTrace();
		}
	}
	
	public void run() {
		while (!theEND) {
			try {
				 Thread.sleep(1000*y);
				 for(int i=0;i<subservers.size();i++) {
					 int count = 0;
					 SubserverInfo subinf = subservers.get(i);
					 while(count<ServerIF.maxTries) {
						 if(subinf.isAvailable())
							 break;
						 ++count;
						 Thread.sleep(500*y);
					 }
					 if (count == ServerIF.maxTries) {
						 removeSubserver(i);
						 continue;
					 }
					 SubserverIF sub = subinf.getSubserver();
					 LinkedList<Item> itemList = sub.getItems();
					 for(int j=0;j<itemList.size();j++) {
						 Item item = itemList.get(j);
						 for(int k=0;k<items.size();k++)
							 if (items.get(k).getID() == item.getID()) {
								 items.get(k).setPrice(item.getPrice());
								 items.get(k).setTimeElapsed(item.getTimeElapsed());
								 LinkedList<Bid> bids = item.getBids(false);
								 items.get(k).getBids(true);
								 for(int m=0;m<bids.size();m++)
									 items.get(k).addBid(bids.get(m));
							 }
					 }
				 }
			} catch (Exception e) {
				theEND = true;
			}
		}
	}

	@Override
	public synchronized Item getItem(long id, boolean remove) throws RemoteException {
		for (int i = 0; i<items.size(); i++){
			Item item = items.get(i);
			if (item.getID() == id) {
				if (remove) 
					items.remove(item);
				return item;
			}
		}
		return null;	
	}

	@Override
	public synchronized long addItem(Item item) throws RemoteException {
		if (activeSubs.size() == 0) {
			item.getSeller().addMessage(new Message("Your listing was put in a waiting queue."));
			long id=++IDItem;
			item.setID(id);
			waiting.add(item);
			log.append(item.toString() + " was put into a waiting queue.");
			return id;
		}
		long id=++IDItem;
		item.setID(id);
		activeSubs.getFirst().getSubserver().addItem(item);
		items.add(item);
		log.append(item.toString() + " was passed to subserver.");
		items.getLast().setSubserver(activeSubs.getFirst());
		item.getSeller().addMessage(new Message("Listing was successfully created."));
		Collections.sort(activeSubs, comp);
		return id;	
	}
	
	@Override
	public synchronized boolean removeItem(long itemID, long clientID) throws RemoteException {
		for(int i=0;i<items.size();i++)
			if (items.get(i).getID() == itemID && items.get(i).getSeller().getID() == clientID) {
				Item item = items.get(i);
				if(!item.getSubserver().isAvailable()) {
					items.get(i).getSeller().addMessage(new Message("Canaceling of a listing failed.\n Try again in a couple of seconds  " + items.get(i).getName() + 
							" " + items.get(i).getID()));
					return false;
				}
				if(item.getSubserver().removeItem(itemID) == false) {
					return false;
				}
				items.get(i).setSubserver(null);
				Collections.sort(activeSubs, comp);
				items.get(i).getSeller().addMessage(new Message("You've succesfully canceled listing:\n " + items.get(i).getName() + 
						" " + items.get(i).getID()));
				items.remove(i);
				log.append(item.toString() + " is removed from server.");
				return true;
			}	
		return false;
	}
	
	@Override
	public synchronized ClientInfoIF login(String name, String password) throws RemoteException {
		for(int i=0;i<clients.size();i++) {
			ClientInfo ci = clients.get(i);
			if (ci.getName().equals(name) && ci.getPassword().equals(password)) {
				log.append("Client " + ci.getName() + " has logged in.");
				return ci;
			}
		}
		return null;	
	}

	@Override
	public synchronized ClientInfoIF signup(String name, String password, int funds) throws RemoteException {
		for(int i=0;i<clients.size();i++) {
			ClientInfo ci = clients.get(i);
			if (ci.getName().equals(name))
				return null;
		}
		ClientInfo cinfo = new ClientInfo(name,password,funds);
		long id = ++IDCli;
		cinfo.setID(id);
		clients.add(cinfo);
		sender.addClient(cinfo);
		gui.dlm.addElement(cinfo.Description());
		log.append("Client " + cinfo.getName() + " has signed in.");
		return cinfo;	
	}
	
	
	@Override
	public synchronized long registerSubserver(String host, String port) throws RemoteException {
		long id;
		String url = "rmi://"+host+":"+port+"/Subserver";
		for(int i=0;i<subservers.size();i++)
			if (subservers.get(i).getURL().equals(url)) {
				subservers.get(i).setSubserver(url);
				activeSubs.add(subservers.get(i));
				for(int j=0;j<waiting.size();j++) {
					Item item = waiting.get(j);
					activeSubs.getLast().getSubserver().addItem(item);
					items.add(item);
					items.getLast().setSubserver(activeSubs.getLast());
					item.getSeller().addMessage(new Message("Your listing is now on auction."));
					log.append(item.toString() + " was passed to subserver.");
				}
				waiting.clear();
				Collections.sort(activeSubs, comp);
				transferItems();
				notifyAll();
				return subservers.get(i).getID();
			}
		id=++IDSub;
		SubserverInfo temp=new SubserverInfo(id,host,port); 
		subservers.add(temp);
		activeSubs.add(temp);
		for(int j=0;j<waiting.size();j++) {
			Item item = waiting.get(j);
			activeSubs.getLast().getSubserver().addItem(item);
			items.add(item);
			items.getLast().setSubserver(activeSubs.getLast());
			item.getSeller().addMessage(new Message("Your listing is now on auction."));
			log.append(item.toString() + " was passed to subserver.");
		}
		waiting.clear();
		Collections.sort(activeSubs, comp);
		transferItems();
		notifyAll();
		return id;	
	}
	
	private synchronized void removeSubserver(int index) {
		long subID = 0;
		try {
			subID = subservers.remove(index).getID();
			log.append("Subserver " + subID + " removed.");
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		if (activeSubs.size() == 0) {
			try {
				wait(1000*z);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		if (activeSubs.size() == 0) {
			for(int i=0;i<items.size();i++) {
				Item item = items.get(i);
				ClientInfoIF seller = item.getSeller();
				LinkedList<Bid> bids = item.getBids(false);
				try {
					seller.removeListing(item.getID());
					seller.addMessage(new Message("Unable to sell " + item.getName() + " ID:" + item.getID() + ". No available subservers."));
					for(int j=0;j<bids.size();j++) {
						Bid bid = bids.get(j);
						ClientInfoIF buyer = bid.getClient();
						buyer.removeBidItem(item.getID());
						buyer.addMessage(new Message("Item " + item.getName() + " ID:" + item.getID() + " was removed from Server(no available subservers)."));
					}
				}catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
			items.clear();
			return;
		}
		
		SubserverInfo subinf = activeSubs.getFirst();
        for(int i=0;i<items.size();i++)
        	if (items.get(i).getSubserverID() == subID) {
        		items.get(i).setSubserver(subinf);
        		subinf.addItem(items.get(i));
        	}
        Collections.sort(activeSubs, comp);	
	}
	
	@Override
	public synchronized void removeFromActiveSubs(long subID) throws RemoteException {
		for(int i=0;i<activeSubs.size();i++)
			if(activeSubs.get(i).getID() == subID) {
				activeSubs.remove(i);
				log.append("Subserver " + subID + " stopped working.");
				break;
			}	
	}

	@Override
	public synchronized ClientInfoIF getClient(long id) throws RemoteException {
		for (int i = 0; i<clients.size(); i++){
			ClientInfoIF client = clients.get(i);
			if (client.getID() == id) 
				return client;
		}
		return null;	
	}
	
	private synchronized void transferItems() {
		if(activeSubs.size()>1) {
			int n1 = activeSubs.getFirst().getNumOfItems();
			int n2 = activeSubs.getLast().getNumOfItems();
			if (n2 - n1 < 2) return;
			int toTransfer = (n2-n1)/2;
			
			for(int i=n2-toTransfer;i<n2;i++) {
				Item item = activeSubs.getLast().takeItem(i);
				if (item == null)
					continue;
				item.setAvailable(true);
				activeSubs.getFirst().addItem(item);
				for(int j=0;j<items.size();j++)
					if(items.get(i).getID() == item.getID())
						items.get(i).setSubserver(activeSubs.getFirst());
			}
			Collections.sort(activeSubs, comp);	
		}
	}
	
	@Override
	public synchronized void addBid(long clientID, long itemID, int offer) throws RemoteException {
		ClientInfoIF ci = getClient(clientID);
		LinkedList<Item> bidItems = ci.getBidItems();
		boolean check=false;
		for(int j=0;j<bidItems.size();j++) {
			if(bidItems.get(j).getID() == itemID) {
				check = true;
				SubserverInfoIF subinf = bidItems.get(j).getSubserver();
				if(!subinf.isAvailable()) {
					ci.addMessage(new Message("Bidding is currently unavailable.\n Try again in a couple of seconds."));
					break;
				}
				if (subinf.addBid(new Bid(ci,itemID,offer),itemID)) {
					ci.addMessage(new Message("You made a successful bid."));
					log.append("Client " + ci.getName() + " made a successful bid for item " + itemID);
				}
				else
					ci.addMessage(new Message("Your offer is not high enough."));
				break;
			}	
		}
		if(!check) {
			for(int i=0; i<items.size();i++) {
				if (items.get(i).getID() == itemID) {
					Item item = items.get(i);
					if (!item.getSubserver().isAvailable()) {
						ci.addMessage(new Message("Bidding is currently unavailable.\n Try again in a couple of seconds."));
						break;
					}
					boolean res =item.getSubserver().addBid(new Bid(ci,itemID,offer), itemID);
					if (res) { 
						ci.addBidItem(item);
						ci.removeFromWishlist(itemID);
						ci.addMessage(new Message("You've made a successful bid."));
						log.append("Client " + ci.getName() + " made a successful bid for item " + itemID);
					}
					else 
						ci.addMessage(new Message("Your offer is not high enough."));
					return;
				}
			}
		}	
	}


	@Override
	public synchronized boolean removeBid(long itemID, long clientID) throws RemoteException {
		for(int i=0;i<items.size();i++) {
			if (items.get(i).getID() == itemID) {
				Item item = items.get(i);
				ClientInfoIF ci = getClient(clientID);
				if (!item.getSubserver().isAvailable()) {
					ci.addMessage(new Message("Canceling of a bid failed. Try again in a couple of seconds."));
					break;
				}
				boolean ret = item.getSubserver().removeBid(itemID, clientID);
				if (ret)
					log.append("Client " + ci.getName() + " removed a bid for item " + itemID);
				return ret;
			}
		}
		return false;
	}

	@Override
	public SubserverInfoIF getSubserver(long id) throws RemoteException {
		for (int i = 0; i < subservers.size(); i++){
			SubserverInfo s = subservers.get(i);
			if (s.getID() == id) return s;
		}
		return null;
	}

	@Override
	public synchronized LinkedList<Item> getAllItems() throws RemoteException {
		LinkedList<Item> list = new LinkedList<>();
		for(int i=0;i<items.size();i++)
			list.add(items.get(i));
		return list;	
	}

	@Override
	public synchronized void end() throws RemoteException, MalformedURLException, NotBoundException {
		sender.end();
		saveSoldItems();
		theEND = true;
		UnicastRemoteObject.unexportObject(this, true);
		Naming.unbind(urlString);
		gui.status.setText("Server Stoped");
		log.append("Server stopped");
		log.write();
		gui.dlm.removeAllElements();
	}
	
	
	public static String getMyIP() {
		try {
			return java.net.InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			return null;
		}
	}

	public synchronized boolean isEND() {
		return theEND;
	}
	
	public void setGUI(ServerGUI sgui) {
		gui = sgui;
	}
	
	@Override
	public void ping(String ip) throws RemoteException {
		if (ip!=null) 
			gui.status.setText("Successfully pinged by: " + ip);
	}
	
	@Override
	public long getTimeX() throws RemoteException {
		return x;
	}
	
	@Override
	public long getTimeT() throws RemoteException {
		return t;
	}
	
	public static void main(String[] args) {
		String serverIP;
		try {
			serverIP = java.net.InetAddress.getLocalHost().getHostAddress();
			int port = Integer.parseInt(args[0]);
			long x = Integer.parseInt(args[1]);
			long y = Integer.parseInt(args[2]);
			long z = Integer.parseInt(args[3]);
			long t = Integer.parseInt(args[4]);
			Server server;
			server = new Server(serverIP, port, null);
			server.setTimeParameters(x, y, z, t);
			ServerGUI sgui = new ServerGUI();
			sgui.start.setEnabled(false);
			server.setGUI(sgui);
			server.raiseServer(true);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public long getTimeZ() throws RemoteException {
		// TODO Auto-generated method stub
		return 0;
	}
}
