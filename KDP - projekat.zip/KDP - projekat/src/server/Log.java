package server;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;

public class Log {
	private StringBuilder string;
	private String file = "server.log";
	public final String sep = "\n-------------------------------------------------\n";
	
	public Log(Object o){
		string = new StringBuilder();
		String p = "Call from: ";
		string.append("\n" + sep + new Date() + "\n" + p + o.getClass() + "\n" + sep + "\n");
	}
	
	public Log(String s, Object o){
		this(o); file = s;
	}
	
	public Log append (String s) {
		string.append(new Date() +  " : ");
		string.append(s); 
		string.append("\n"); 
		return this;
	}
	
	public Log append (String[] p_s){
		string.append(new Date() +  " : ");
		for(int i=0; i<p_s.length; i++) string.append(p_s[i] + "\n");
		return this;
	}
	
	public void write(){
		try {
			File filee = new File(file);
			if (filee.exists()) filee.delete();
			BufferedWriter out = new BufferedWriter(new FileWriter(filee));
			out.write(string.toString());
			out.close();
			
		} catch (Exception e) {
				System.err.println("Error: Error while writing into log file.");
				e.printStackTrace();
		}
		
	}
}
