package server;

import java.net.MalformedURLException;
import java.rmi.*;
import java.util.LinkedList;

import misc.*;
import subserver.*;
import client.*;

public interface ServerIF extends Remote {

	public static final int maxTries = 3;
	
	Item getItem(long id, boolean remove) throws RemoteException;
	
	long addItem(Item item) throws RemoteException;
	
	boolean removeItem(long itemID, long clientID) throws RemoteException;
	
	ClientInfoIF login(String name, String password) throws RemoteException;
	
	ClientInfoIF signup(String name, String password, int funds) throws RemoteException;
	
	ClientInfoIF getClient(long id) throws RemoteException;
	
	long registerSubserver(String host, String port) throws RemoteException;
	
	void removeFromActiveSubs(long id) throws RemoteException;
	
	SubserverInfoIF getSubserver(long id) throws RemoteException;
	
	void addBid(long clientID, long itemID, int offer) throws RemoteException;
	
	boolean removeBid(long itemID, long clientID) throws RemoteException;
	
	LinkedList<Item> getAllItems() throws RemoteException;
	
	void ping(String string) throws RemoteException;
	
	void end() throws RemoteException, MalformedURLException, NotBoundException;
	
	long getTimeX() throws RemoteException;
	
	long getTimeT() throws RemoteException;
	
	long getTimeZ() throws RemoteException;
	
}
