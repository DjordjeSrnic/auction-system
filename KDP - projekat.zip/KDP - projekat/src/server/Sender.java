package server;

import java.rmi.RemoteException;

import java.util.LinkedList;

import client.ClientInfoIF;
import misc.Item;

public class Sender implements Runnable {

	private ServerIF server;
	private LinkedList<Item> items;
	private LinkedList<ClientInfoIF> clients;
	private Thread myThread = null;
	private volatile boolean theEND = false;
	private static final int x = 3;
	
	public Sender(ServerIF s, LinkedList<Item> list) {
		server = s;
		items = list;
		clients = new LinkedList<>();
	}
	
	public void run() {
		while(!theEND){
			try {
				Thread.sleep(x*1000);
				for(int i=0;i<items.size();i++) {
					updateClients(items.get(i));
				}
			} catch (Exception e) {
				theEND = true;
			}
		}
	}
	
	private void updateClients(Item item) {
		synchronized(this) {
			
			for(int i=0;i<clients.size();i++) {
				ClientInfoIF client = clients.get(i);
				try {
					client.update(item.getID(), item.getPrice(), item.getTimeElapsed());
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void addClient(ClientInfoIF client) {
		synchronized(this) {
			clients.add(client);
		}
	}
	
	public void start () {
		if (myThread == null){
			myThread = new Thread(this, "ServerCheck");
			myThread.start();
		}
	}
	public void stop () {
		Thread stopThread = myThread;
		myThread = null;
		stopThread.interrupt();
		theEND = true;
	}
	
	public void end () {
		theEND = true;
	}
	
}
