package server;

import javax.swing.*;

import client.ClientGUI;

import java.awt.*;
import java.awt.event.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;

public class ServerGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	public DefaultListModel<String> dlm = new DefaultListModel<String>();
	private JList<String> subscribers = new JList<>(dlm);
	public JButton start = new JButton("Run Server");
	public JButton end = new JButton("Stop Server");
	public JTextField ip = new JTextField();
	public JTextField port = new JTextField(Server.DefaultPort);
	public JTextArea status = new JTextArea();
	public JTextField x = new JTextField();
	public JTextField y = new JTextField();
	public JTextField z = new JTextField();
	public JTextField t = new JTextField();
	private Dimension dim = new Dimension(600,300);
	private Server server;
	private LinkedList<Integer> oldPorts = new LinkedList<>();

	public ServerGUI() {
		init();
		setVisible(true);
	}
	
	private void init() {
		setTitle("Server");
		this.addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		    	if (server != null && !server.isEND())
					try {
						server.end();
					} catch (Exception e1) {
						
					}
		    	System.exit(0);
		    }});
		this.setMinimumSize(dim);
		this.setPreferredSize(dim);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(7,1));
		panel.add(new JLabel("Server IP"));
		panel.add(ip);
		ip.setText(server.getMyIP());
		ip.setEditable(false);
		panel.add(new JLabel("Server Port"));
		panel.add(port);
		JPanel timeParams = new JPanel(new GridLayout(2,4));
		timeParams.add(new JLabel("x[s]", SwingConstants.CENTER));
		timeParams.add(new JLabel("y[s]", SwingConstants.CENTER));
		timeParams.add(new JLabel("z[s]", SwingConstants.CENTER));
		timeParams.add(new JLabel("t[min]", SwingConstants.CENTER));
		timeParams.add(x);
		timeParams.add(y);
		timeParams.add(z);
		timeParams.add(t);
		panel.add(timeParams);
		panel.add(start);
		panel.add(end);
		end.setEnabled(false);
		start.addActionListener(new Starter(this));
		end.addActionListener(new Stopper());
		JPanel p = new JPanel(new GridLayout(1,2));
		JScrollPane scroll = new JScrollPane(subscribers);
		p.add(scroll);
		p.add(panel);
		JPanel southPanel = new JPanel(new GridLayout(2,1));
		southPanel.add(new JLabel("Status"));
		southPanel.add(status);
		add(p);
		add(southPanel,BorderLayout.SOUTH);
		this.setVisible(true);
	}
	
	class Starter implements ActionListener{
		private ServerGUI sgui;
		
		public Starter(ServerGUI sg) {
			sgui = sg;
		}
		
		boolean checkTimeParams(long x, long y, long z) {
			return x > y && z > 2*x;
		}
		
		public boolean isOldPort(int port) {
			for(int i=0;i<oldPorts.size();i++)
				if(oldPorts.get(i).equals(port))
					return true;
			return false;
		}
		
		public void actionPerformed(ActionEvent e){
			try {
				long timex = Long.parseLong(x.getText());
				long timey = Long.parseLong(y.getText());
				long timez = Long.parseLong(z.getText());
				long timet = Long.parseLong(t.getText());
				if (Integer.parseInt(port.getText())>1000 && checkTimeParams(timex,timey,timez)){
					server = new Server(Integer.parseInt(port.getText()), sgui);
				    start.setEnabled(false);
					boolean flag = isOldPort(Integer.parseInt(port.getText()));
					if (!flag) 
						oldPorts.add(Integer.parseInt(port.getText()));
					server.raiseServer(!flag);
					server.setTimeParameters(timex, timey, timez, timet);
					server.start();
					end.setEnabled(true);
				}
				else if (Integer.parseInt(port.getText())<=1000){
					status.setText("Port number has to be bigger than 1000");
				}
				else 
					status.setText("Time parameters are bad.");
			} catch (Exception e1) {
				status.setText(e1.getMessage());
			}
		}
	};
	
	class Stopper implements ActionListener{
		public void actionPerformed(ActionEvent e){
			try {
				server.end();
			} catch (Exception e1) {
				
			}	
			start.setEnabled(true);
			end.setEnabled(false);
		}
	};
	
	public static void main(String[] args) {
		new ServerGUI();
	}
}
