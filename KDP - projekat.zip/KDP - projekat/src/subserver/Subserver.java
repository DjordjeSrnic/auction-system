package subserver;

import java.io.*;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;

import client.Client;
import client.ClientInfo;
import client.ClientInfoIF;
import misc.*;
import server.*;

public class Subserver extends UnicastRemoteObject implements SubserverIF, Runnable, Serializable {

	private static final long serialVersionUID = 1L;
	public static final int DefaultPort = 4001;
	private String serverHost;
	private String myHost;
	private int serverPort;
	private int myPort;
	private long id;
	public ServerIF server;
	private Thread myThread;
	private SubserverGUI gui;
	private LinkedList<Item> items = new LinkedList<>();
	private long t;
	public long z;
	private boolean theEND;
	
	public Subserver (String serverHost, int servport, String myHost, int myport, SubserverGUI gui) throws RemoteException {
		this.gui = gui;
		this.serverHost = serverHost;
		this.serverPort = servport;
		this.myHost = myHost;
		this.myPort = myport;
	}
	
	public Subserver (String serverHost, int port, int myport, SubserverGUI gui) throws Exception {
		this(serverHost, port, java.net.InetAddress.getLocalHost().getHostAddress(),myport,gui);
	}
	
	public void makeNewConnection(boolean flag) throws Exception {
		String servurl = "//" + serverHost + ":" + serverPort + "/Server";
		try {
			System.setSecurityManager(new RMISecurityManager());
			String suburl = "rmi://" + myHost + ":" + myPort + "/Subserver";
			if (flag) LocateRegistry.createRegistry(myPort);
			Naming.rebind(suburl, this);
			gui.status.setText("Connecting...");
			server = (ServerIF) Naming.lookup(servurl);
			t = server.getTimeT();
			z = server.getTimeZ();
			gui.status.setText("Connected on " + servurl);
		} catch (Exception e){
			System.out.println(e.getMessage());
			throw new Exception("Connection failed. Server isn't at " + servurl);
		}
	}
	
	public void start() {
			if (myThread == null){
				myThread = new Thread(this, "Subserver");
				myThread.start();
			}
	}
	
	public void end() throws RemoteException, MalformedURLException, NotBoundException {
		synchronized(this) {
			try {
				String ip = java.net.InetAddress.getLocalHost().getHostAddress();
				server.ping(ip);
				server.getSubserver(id).saveItems(items);
				server.removeFromActiveSubs(id);
				Thread stopThread = myThread;
				myThread = null;
				stopThread.interrupt();
				theEND = true;
				for(int i=0;i<items.size();i++)
					items.get(i).setAvailable(false);;
				gui.dlmItems.removeAllElements();
				String suburl = "rmi://" + myHost + ":" + myPort + "/Subserver";
				Naming.unbind(suburl);
				gui.status.setText("Disconnected from " + "//" + serverHost + ":" + serverPort + "/Server");
			} catch (Exception e) {

			}
		}
	}
	
	@Override
	public void run() {
		while(!theEND) {
			try {
				Thread.sleep(2*1000);
				String ip = java.net.InetAddress.getLocalHost().getHostAddress();
				server.ping(ip);
				gui.dlmItems.clear();
				for(int i=0;i<items.size();i++) {
					Item item = items.get(i);
					if (!item.isSold())
						gui.dlmItems.addElement(items.get(i).toString());
					else {
						items.remove(i);
						server.getItem(item.getID(), true);
					}
				}	
			} catch (Exception e) {
				theEND = true;
				System.out.println("INTERRUPTED " + e.getMessage());
				String suburl = "rmi://" + myHost + ":" + myPort + "/Subserver";
				try {
					UnicastRemoteObject.unexportObject(this, true);
					Naming.unbind(suburl);
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
				}
				gui.dlmItems.removeAllElements();
				gui.connect.setEnabled(true);
				gui.disconnect.setEnabled(false);
				gui.status.setText("Disconnected from " + "//" + serverHost + ":" + serverPort + "/Server");
			}
		}
	}
	
	@Override
	public synchronized void addItem(Item item) throws RemoteException {
		Worker worker = new Worker(item,this,t);
		items.add(item);
	}
	
	@Override
	public synchronized boolean removeItem(long itemID) throws RemoteException {
		for(int i=0;i<items.size();i++) {
			Item item = items.get(i);
			if (item.getID() == itemID && item.getTimeElapsed() >= server.getTimeZ() && item.isActive()) {
				items.get(i).setAvailable(false);
				LinkedList<Bid> bids = item.getBids(true);
				for(int j=0;j<bids.size();j++) {
					ClientInfoIF ci = bids.get(j).getClient();
					ci.removeBidItem(item.getID());
				}
				items.remove(i);
				return true;
			}
		}
		return false;
	}
	
	@Override
	public synchronized boolean addBid(Bid bid, long itemID) throws RemoteException {
		boolean retval = false;
		for(int i=0;i<items.size();i++) {
			if (items.get(i).getID() == itemID) {
				retval = items.get(i).addBid(bid);
				break;
			}
		}
		return retval;
	}
	
	@Override
	public synchronized boolean removeBid(long itemID, long clientID) throws RemoteException {
		boolean retval = false;
		for(int i=0;i<items.size();i++) {
			if (items.get(i).getID() == itemID) {
				retval = items.get(i).removeBid(clientID);
				break;
			}
		}
		return retval;
	}
	
	@Override
	public void setID(long id) throws RemoteException {
		this.id = id;
		
	}
	
	@Override
	public long getID() throws RemoteException {
		return id;
	}
	
	@Override
	public int getNumOfItems() throws RemoteException {
		return items.size();
	}
	
	@Override
	public LinkedList<Item> getItems() throws RemoteException {
		return items;
	}
	
	@Override
	public synchronized Item takeItem(int index) throws RemoteException {
		if (!items.get(index).isActive())
			return null;
		items.get(index).setAvailable(false);
		Item item = items.remove(index);
		return item;
	}
	
	@Override
	public void loadItems(LinkedList<Item> list) throws RemoteException {
		for(int i=0;i<list.size();i++) {
			list.get(i).setAvailable(true);
			Worker worker = new Worker(list.get(i),this,t);
			items.add(list.get(i));	
		}
	}

	@Override
	public void setInterested(long itemID, boolean val) {
		for(int i=0;i<items.size();i++)
			if(items.get(i).getID() == itemID) {
				items.get(i).setInterested(val);
				break;
			}
	}

	public static String getMyIP() {
		try {
			return java.net.InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			return null;
		}
	}
	
	public boolean check() {
		return !theEND;
	}
	
	public ServerIF getServer() throws RemoteException {
		return server;
	}
}
