package subserver;

import java.rmi.Remote;

import java.rmi.RemoteException;
import java.util.LinkedList;

import client.Client;
import client.ClientInfoIF;
import misc.Bid;
import misc.Item;
import server.ServerIF;
import misc.Item;

public interface SubserverIF extends Remote {
	
	void addItem(Item item) throws RemoteException;
	
	boolean removeItem(long itemID) throws RemoteException;
	
	boolean addBid(Bid bid, long itemID) throws RemoteException;
	
	boolean removeBid(long clientID, long itemID) throws RemoteException;
	
	void setID(long id) throws RemoteException;
	
	long getID() throws RemoteException;
	
	int getNumOfItems() throws RemoteException;
	
	LinkedList<Item> getItems() throws RemoteException;
	
	Item takeItem(int index) throws RemoteException;
	
	void loadItems(LinkedList<Item> list) throws RemoteException;

	void setInterested(long itemID, boolean val) throws RemoteException;
	
	ServerIF getServer() throws RemoteException;

}