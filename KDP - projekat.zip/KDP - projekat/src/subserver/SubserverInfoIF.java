package subserver;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.LinkedList;

import misc.Bid;
import misc.Item;

public interface SubserverInfoIF extends Remote {

	void saveItems(LinkedList<Item> list) throws RemoteException;
	
	void setInterested(long itemID, boolean val) throws RemoteException;
	
	boolean isAvailable() throws RemoteException;
	
	boolean removeItem(long itemID) throws RemoteException;
	
	Item takeItem(int index) throws RemoteException;
	
	boolean addBid(Bid bid, long itemID) throws RemoteException;
	
	boolean removeBid(long clientID, long itemID) throws RemoteException;
	
	long getID() throws RemoteException;
	
	long getTimeZ() throws RemoteException;
}
