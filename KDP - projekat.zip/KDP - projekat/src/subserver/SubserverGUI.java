package subserver;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.LinkedList;

public class SubserverGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	private Dimension dimenzijeProzora = new Dimension(900, 300);
	private JTextField port= new JTextField();
	private JTextField ip = new JTextField();
	private JTextField myport= new JTextField();
	private JTextField myip = new JTextField();
	public DefaultListModel<String> dlmItems = new DefaultListModel<String>();
	public DefaultListModel<String> dlmBids = new DefaultListModel<String>();
	public JList<String> bids = new JList<>(dlmBids);
	public JList<String> items = new JList<>(dlmItems);
	public JButton connect = new JButton ("Start Subserver");
	public JButton disconnect = new JButton ("Stop Subserver");
	public JTextArea status = new JTextArea();
	private Subserver subserver;
	private LinkedList<Integer> oldPorts = new LinkedList<>();
	
	public SubserverGUI () {
		init();
		setVisible(true);
	}
	
	private void init() {
		setTitle("Subserver");
		this.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
	    	if (subserver!=null)
				try {
					if (subserver.check()) {
						subserver.end();
					}
				} catch (RemoteException e1) {
					e1.printStackTrace();
				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				} catch (NotBoundException e1) {
					e1.printStackTrace();
				}
		    	System.exit(0);
	    }});
		setPreferredSize(dimenzijeProzora);
		setMinimumSize(dimenzijeProzora);
		setResizable(true);
		JPanel panel = new JPanel(new GridLayout(1,3));
		JPanel options = new JPanel();
		options.setLayout(new GridLayout(10,1));
		options.add(new JLabel("Server IP"));
		options.add(ip);
		ip.addFocusListener(new Focuser());
		options.add(new JLabel("Server Port"));
		options.add(port);
		options.add(new JLabel("My IP"));
		myip.setText(subserver.getMyIP());
		myip.setEditable(false);
		options.add(myip);
		options.add(new JLabel("My Port"));
		options.add(myport);
		options.add(connect);
		options.add(disconnect);
		connect.addActionListener(new Starter(this));
		disconnect.addActionListener(new Stopper(this));
		disconnect.setEnabled(false);
		items.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		bids.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		options.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		JScrollPane scroll = new JScrollPane(items);
		panel.add(scroll);
		panel.add(options);
		JPanel southPanel = new JPanel(new GridLayout(2,1));
		southPanel.add(new JLabel("Status"));
		southPanel.add(status);
		add(panel);
		add(southPanel,BorderLayout.SOUTH);
	}
	
	class Focuser implements FocusListener {
		public void focusGained(FocusEvent arg0) {
			ip.setBackground(new Color(255, 255, 255));			
		}
		public void focusLost(FocusEvent arg0) {
						
		}	
	}
	
	class Starter implements ActionListener {
		public SubserverGUI win;
		public Starter (SubserverGUI jf) {
			win = jf;
		}
		public boolean isIP (String ip) {
			try {
		        if ( ip == null || ip.isEmpty() ) {
		            return false;
		        }

		        String[] parts = ip.split( "\\." );
		        if ( parts.length != 4 ) {
		            return false;
		        }

		        for ( String s : parts ) {
		            int i = Integer.parseInt( s );
		            if ( (i < 0) || (i > 255) ) {
		                return false;
		            }
		        }
		        if ( ip.endsWith(".") ) {
		            return false;
		        }

		        return true;
		    } catch (NumberFormatException nfe) {
		        return false;
		    }
		}
		
		public boolean isOldPort(int port) {
			for(int i=0;i<oldPorts.size();i++)
				if(oldPorts.get(i).equals(port))
					return true;
			return false;
		}
		
		public void actionPerformed(ActionEvent e){
			try {
				if (Integer.parseInt(port.getText())<1000){
					status.setText("Port mora biti veci od 1000");
					return;
				}
				if (isIP(ip.getText())) {
					String servIP = ip.getText();
					int servPort = Integer.parseInt(port.getText());
					int myPort = Integer.parseInt(myport.getText());
					boolean flag = isOldPort(myPort);
					if(!flag)
						oldPorts.add(myPort);
					subserver = new Subserver (servIP,servPort,myPort, win);
					subserver.makeNewConnection(!flag);
					long id = subserver.server.registerSubserver(myip.getText(),myport.getText());
					subserver.setID(id);
					subserver.start();
					win.setTitle("Subserver " + id);
					connect.setEnabled(false);
					disconnect.setEnabled(true);
				}
			} catch (Exception e1) {
				status.setText(e1.getMessage());
			}
		}
	};
	
	class Stopper implements ActionListener{
		public JFrame win;
		public Stopper (JFrame jf) {
			win = jf;
		}
		public void actionPerformed(ActionEvent e){
			try {
				subserver.end();
			} catch (RemoteException | MalformedURLException | NotBoundException e1) {
				e1.printStackTrace();
			}
			connect.setEnabled(true);
			disconnect.setEnabled(false);
		}
	};
	
	public static void main(String[] args) {
		SubserverGUI sgui1 = new SubserverGUI();
	}
}
