package subserver;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;

import misc.Bid;
import misc.Item;

public class SubserverInfo extends UnicastRemoteObject implements Serializable, SubserverInfoIF {
	private static final long serialVersionUID = 1L;
	private long id;
	private String url;
	private SubserverIF subserver;
	private LinkedList<Item> items = new LinkedList<>();
	private boolean assigned;
	
	public SubserverInfo(long id, String host, String port) throws RemoteException {
		this.assigned=true;
		this.url="rmi://"+host+":"+port+"/Subserver"; 
		this.id=id;									   
		Object remote;
		try {
			remote = Naming.lookup(url);
			subserver = (SubserverIF)remote;
		} catch (MalformedURLException e1) {e1.printStackTrace();}
		  catch (RemoteException e1) {e1.printStackTrace();} 
		  catch (NotBoundException e1) {e1.printStackTrace();}
	}
	
	
	public long getID() throws RemoteException {
		return id;
	}

	public String getURL() {
		return url;
	}

	public void setSubserver(String url) {
		synchronized(this) {
			Object remote;
			try {
				remote = Naming.lookup(url);
				subserver = (SubserverIF) remote;
				subserver.loadItems(items);
				items.clear();
				assigned = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public SubserverIF getSubserver() {
		synchronized(this) {
			return subserver;
		}
	}
	
	public void addItem(Item item) {
		try {
			subserver.addItem(item);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Item takeItem(int index) {
		try {
			return subserver.takeItem(index);
		} catch (RemoteException e) {
		}
		return null;
	}
	
	public boolean addBid(Bid bid, long itemID) throws RemoteException {
		return subserver.addBid(bid, itemID);
	}
	
	public boolean removeBid(long itemID, long clientID) throws RemoteException {
		return subserver.removeBid(itemID, clientID);
	}
	
	public boolean removeItem(long itemID) {
		try {
			return subserver.removeItem(itemID);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public int getNumOfItems() {
		try {
			return subserver.getNumOfItems();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public boolean isAvailable() {
		synchronized(this) {
			return assigned;
		}
	}
	
	public void saveItems(LinkedList<Item> list) throws RemoteException {
		synchronized(this) {
			assigned = false;
			for(int i=0;i<list.size();i++) {
				items.add(list.get(i));
			}	
		}
	}


	@Override
	public long getTimeZ() throws RemoteException {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public void setInterested(long itemID, boolean val) throws RemoteException {
		subserver.setInterested(itemID, val);
	}
}
