package subserver;


import java.util.LinkedList;

import client.ClientInfoIF;
import misc.Bid;
import misc.Item;
import misc.Message;

public class Worker extends Thread {

	private Item item;
	private SubserverIF subserver;
	private long t;
	private boolean isActive;
	
	public Worker(Item item, SubserverIF sub, long t) {
		this.item = item;
		this.subserver = sub;
		this.t = t;
		this.isActive = true;
		start();
	}
	
	private void transfer(ClientInfoIF buyer, ClientInfoIF seller, long amount) {
		try {
			buyer.removeFunds(amount);
			seller.addFunds(amount);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public void run() {
		while(isActive) {
			try {
				long startTime = System.currentTimeMillis();
				long auctionTime = item.getTime()*1000  - item.getTimeElapsed()*1000;
				long endTime = startTime + auctionTime;
				long passedTime = item.getTimeElapsed();
				
				while(System.currentTimeMillis()<endTime && item.isAvailable()) {
					long elapsed = (System.currentTimeMillis() - startTime)/1000;
					item.setTimeElapsed(elapsed + passedTime);
				}
				
				if (!item.isAvailable())
					throw new Exception("Interrupted");
				
				item.setActive(false);
			
				LinkedList<Bid> bids = item.getBids(false);
				
				System.out.println("\nBIDS SIZE: " + bids.size() + "\n");
				
				if (bids.size()>=1 && item.isAvailable()) {
					Bid bid = bids.get(0);
					if (bid.getClient().getSum() >= item.getPrice() && item.isAvailable()) {
						ClientInfoIF buyer = bid.getClient();
						ClientInfoIF seller = item.getSeller();
						transfer(buyer,seller,item.getPrice());
						item.getBids(true);
						for(int i=0;i<bids.size();i++) {
							ClientInfoIF ci = bids.get(i).getClient();
							ci.removeBidItem(item.getID());
						}
						item.setBuyer(buyer);
						buyer.addBoughtItem(item);
						item.setSold(true);
						seller.removeListing(item.getID());
						seller.addSoldItem(item);
						buyer.addMessage(new Message("You've successfully bought " + item.getName()));
						seller.addMessage(new Message("You've successfully sold " + item.getName()));	
						isActive = false;
					}
					else {
						Thread.sleep(t*60000);
						if (bid.getClient().getSum() >= item.getPrice()) {
							ClientInfoIF buyer = bid.getClient();
							ClientInfoIF seller = item.getSeller();
							transfer(buyer,seller,item.getPrice());
							item.getBids(true);
							for(int i=0;i<bids.size();i++) {
								ClientInfoIF ci = bids.get(i).getClient();
								ci.removeBidItem(item.getID());
							}
							item.setBuyer(buyer);
							buyer.addBoughtItem(item);
							item.setSold(true);
							seller.removeListing(item.getID());
							seller.addSoldItem(item);
							buyer.addMessage(new Message("You've successfully bought " + item.getName()));
							seller.addMessage(new Message("You've successfully sold " + item.getName()));
							isActive = false;
						}
						else {
							if (bids.size()>=2 && item.isAvailable()) {
								Bid firstBid = bids.get(0);
								Bid secondBid = bids.get(1);
								firstBid.getClient().removeBidItem(item.getID());
								bids.remove(0);
								item.setPrice(secondBid.getOffer());
								secondBid.getClient().addMessage(new Message("Listing " + item.getName() + " with ID: " + item.getID() +
											"\n is available for you to buy on subserver " + subserver.getID() + ".\n Answer within " + t + " minutes."));
								Thread.sleep(t*60000);
								if (item.getInterested() && secondBid.getClient().getSum() >= item.getPrice()) {
										ClientInfoIF buyer = secondBid.getClient();
										ClientInfoIF seller = item.getSeller();
										transfer(buyer,seller,item.getPrice());
										item.getBids(true);
										for(int i=0;i<bids.size();i++) {
											ClientInfoIF ci = bids.get(i).getClient();
											ci.removeBidItem(item.getID());
										}
										item.setBuyer(buyer);
										buyer.addBoughtItem(item);
										item.setSold(true);
										seller.removeListing(item.getID());
										seller.addSoldItem(item);
										buyer.addMessage(new Message("You've successfully bought " + item.getName()));
										seller.addMessage(new Message("You've successfully sold " + item.getName()));
										item.setInterested(false);
										isActive = false;
								}
								else {
									item.setTimeElapsed(0);
									item.setInterested(false);
									item.setPrice(item.getDefaultPrice());
									long ID = item.getID();
									for(int i=0;i<bids.size();i++) {
										ClientInfoIF ci = bids.get(i).getClient();
										ci.removeBidItem(ID);
										item.removeBid(ci.getID());
									}
									item.getBids(true);
									item.setActive(true);
								}
							}
							else {
								item.setTimeElapsed(0);
								item.setPrice(item.getDefaultPrice());
								long ID = item.getID();
								for(int i=0;i<bids.size();i++) {
									ClientInfoIF ci = bids.get(i).getClient();
									ci.removeBidItem(ID);
									item.removeBid(ci.getID());
								}
								item.getBids(true);
								item.setActive(true);
							}
						}
					}
				} else {
					item.setTimeElapsed(0);
					item.setPrice(item.getDefaultPrice());
					item.setActive(true);
				}
			} catch(Exception e) {
				System.out.println(e.getMessage());
				isActive = false;
			}
		}
	}
}
