package misc;

import java.io.Serializable;

public class BankAccount implements Serializable {

	private long sum;
	
	public BankAccount(long sum) {
		this.sum = sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public void add(long amount) {
		sum += amount;
	}
	
	public void sub(long amount) {
		sum -= amount;
	}

	public long getSum() {
		return sum;
	}

}
