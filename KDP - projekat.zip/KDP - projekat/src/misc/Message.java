package misc;

import java.io.Serializable;

public class Message implements Serializable {

	private String text;
	
	public Message(String t) {
		text = t;
	}
	
	public String content() {
		return text;
	}
}
