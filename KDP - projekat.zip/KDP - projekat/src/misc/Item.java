package misc;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.regex.Pattern;

import client.ClientInfoIF;
import subserver.SubserverInfoIF;

public class Item implements Serializable {
	private static final long serialVersionUID = 1L;
	private long id;
	private String name;
	private long price;
	private long defaultPrice;
	private String desc;
	private long time;
	private long timeElapsed;
	private long z;
	private ClientInfoIF seller;
	private ClientInfoIF buyer;
	private boolean active;
	private boolean available;
	private boolean sold;
	private SubserverInfoIF subserver;
	private boolean interested = false;
	private LinkedList<Bid> bids = new LinkedList<>();
	private MyComparator comp = new MyComparator();
	
	class MyComparator implements Comparator<Bid>, Serializable {
		private static final long serialVersionUID = 1L;

		@Override
		public int compare(Bid b1, Bid b2) {
			if(b1.getOffer() < b2.getOffer()){
	            return 1;
	        } else {
	            return -1;
	        }
		}
	}
	
	@SuppressWarnings("resource")
	public Item(File file) throws Exception {
		try {
			long size = file.length();
			size = size/(1024*1024);
			if (size>=60) throw new Exception("File is too large.");
			StringBuffer sb = new StringBuffer ();
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String s;
			while ((s = in.readLine()) != null){
				sb.append(s+"\n");
			}
			if (sb.toString().split("\n").length<4) throw new Exception("Bad file format.");
			init(sb.toString().split("\n"));
			active = true;
			available = true;
			sold = false;
			in.close();
		} catch (FileNotFoundException e) {
			throw new Exception("File doesn't exist.");
		} catch (IOException e) {
			throw new Exception("Error while reading from file.");
		}
	}
	
	public Item(String nm, String descr, String pr, String t) throws Exception {
			name = nm;
			if (name.length()>0) {
				throw new Exception("Name is wrong.");
			}
			
			desc = descr;
			if (desc.length()>0) {
				throw new Exception("Description is wrong.");
			}
			
			try {
				price = Long.parseLong(pr);
				defaultPrice = price;
			} catch(NumberFormatException e) {
				throw new Exception("Price is wrong.");
			}
			
			try {
				time = Long.parseLong(t);
			} catch(NumberFormatException e) {
				throw new Exception("Time is wrong.");
			}
			active = true;
			available = true;
			sold = false;
	}
	
	private void init (String[] in) throws Exception {
		int j = 0;
		String s = in[j];
		if (s.split("=").length==2 && s.split("=")[0].equals("Name")){
			name = s.split("=")[1];
		}
		else throw new Exception("Bad file format.");
		s = in[++j];
		if (s.split("=").length==2 && s.split("=")[0].equals("Desc")){
			desc = s.split("=")[1];
		}
		else throw new Exception("Bad file format.");
		s = in[++j];
		if (s.split("=").length==2 && s.split("=")[0].equals("Price")){
			try {
				price = Long.parseLong(s.split("=")[1]);
				defaultPrice = price;
			} catch(NumberFormatException e) {
				throw new Exception("Price is wrong.");
			}
		}
		else throw new Exception("Bad file format.");
		s = in[++j];
		if (s.split("=").length==2 && s.split("=")[0].equals("Time")){
			try {
				time = Long.parseLong(s.split("=")[1]);
			} catch(NumberFormatException e) {
				throw new Exception("Time is wrong.");
			}
		}
		else throw new Exception("Bad file format.");
	}
	
	public void setID(long id) {
		this.id = id;
	}
	
	public long getID() {
		return id;
	}
	
	public void setSubserver(SubserverInfoIF sub) {
		subserver = sub;
	}
	
	public SubserverInfoIF getSubserver() {
		return subserver;
	}
	
	public long getSubserverID() {
		try {
			return subserver.getID();
		} catch (Exception e) {
		}
		return 0;
	}
	
	public synchronized boolean addBid(Bid b) {
		if (timeElapsed < time) {
			if(bids.isEmpty()) {
				if (b.getOffer() >= price) {
					bids.add(b);
					price = b.getOffer();
					return true;
				}
				else 
					return false;
			}
			if (bids.get(0).getOffer() < b.getOffer()) {
				for(int i=0;i<bids.size();i++) {
					try {
						if (bids.get(i).getClient().getID() == b.getClient().getID()) {
							long clientID = bids.remove(i).getClient().getID();
							removeBid(clientID);
							bids.add(b);
							price = b.getOffer();
							Collections.sort(bids, comp);
							return true;
						}
					} catch(Exception e) {
						System.out.println(e.getMessage());
					}
				}
				bids.add(b);
				price = b.getOffer();
				Collections.sort(bids, comp);
				return true;
			}
			else
				return false;
		}
		else 
			return false;
	}
	
	public synchronized boolean removeBid(long clientID) {
			if (timeElapsed >= z && active) {
				for(int i=0;i<bids.size();i++)
					try {
						if (bids.get(i).getClient().getID() == clientID) {
							if (price == bids.get(i).getOffer())
								if (bids.size() >= 2)
									price = bids.get(1).getOffer();
								else 
									price = defaultPrice;
							bids.remove(i);
							return true;
						}
					} catch(Exception e) {
						System.out.println(e.getMessage());
					}
				return false;
			}
		return false;
	}
	
	public LinkedList<Bid> getBids(boolean andRemove) {
		LinkedList<Bid> list = new LinkedList<>(bids);
		if (andRemove)
			bids.clear();
		return list;
	}
	
	public void setBuyer(ClientInfoIF buyer) {
		this.buyer = buyer;
	}
	
	public ClientInfoIF getBuyer() {
		return buyer;
	}
	
	public void setSeller(ClientInfoIF seller) {
		this.seller = seller;
	}
	
	public ClientInfoIF getSeller() {
		return seller;
	}
	
	public synchronized void setTimeElapsed(long elapsed) {
		timeElapsed = elapsed;
	}
	
	public synchronized long getTimeElapsed() {
		return timeElapsed;
	}
	
	public long getTime() {
		return time;
	}
	
	public synchronized void setPrice(long newPrice) {
		price = newPrice;
	}
	
	public synchronized long getPrice() {
		return price;
	}
	
	public long getDefaultPrice() {
		return defaultPrice;
	}
	
	public synchronized void setInterested(boolean val) {
		interested = val;
	}
	
	public synchronized boolean getInterested() {
		return interested;
	}
	
	public String getName() {
		return name;
	}
	
	public synchronized void setAvailable(boolean val) {
		available = val;
	}
	
	public synchronized boolean isAvailable() {
		return available;
	}
	
	public synchronized void setActive(boolean val) {
		active = val;
	}
	
	public synchronized boolean isActive() {
		return active;
	}
	
	public synchronized void setSold(boolean val) {
		sold = val;
	}
	
	public synchronized boolean isSold() {
		return sold;
	}
	
	public String getDescription() {
		return desc;
	}
	
	public void setTimeZ(long z) {
		this.z = z;
	}
	
	@Override
	public String toString() {
		return "ID: " + id + " NAME: " + name + " DESCRIPTION: " + desc + " PRICE: " + price + " TIME LEFT: " + (time - timeElapsed) + "s";
	}
}
