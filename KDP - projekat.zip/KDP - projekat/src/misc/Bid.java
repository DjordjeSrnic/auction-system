package misc;

import java.io.Serializable;

import java.rmi.RemoteException;

import client.Client;
import client.ClientInfo;
import client.ClientInfoIF;

public class Bid implements Serializable {

	private ClientInfoIF client;
	private long itemID;
	private int offer;
	
	public Bid(ClientInfoIF client, long id, int offer) {
		this.client = client;
		this.itemID = id;
		this.offer = offer;
	}
	
	public ClientInfoIF getClient() {
		return client;
	}
	
	public long getItemID() {
		return itemID;
	}
	
	public int getOffer() {
		return offer;
	}
	
	public String toString() {
		try {
			return client.Description() + " PONUDA: " + offer;
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return "";
	}
}
