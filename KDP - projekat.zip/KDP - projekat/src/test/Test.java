package test;

import client.ClientGUI;
import server.ServerGUI;
import subserver.SubserverGUI;

public class Test {

	public static void main(String[] args) {
		ServerGUI server = new ServerGUI();
		SubserverGUI subserver = new SubserverGUI();
		ClientGUI client1 = new ClientGUI();
		ClientGUI client2 = new ClientGUI();
	}
}
