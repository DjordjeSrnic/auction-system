package client;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;

public class Messages extends JDialog {

	private static final long serialVersionUID = 1L;
	public JTextArea messages = new JTextArea();
	public JTextField subID = new JTextField();
	public JTextField itemID = new JTextField();
	public JButton answer = new JButton("Answer");
	public JTextArea status = new JTextArea();
	public int numOfQuestions = 0;
	public int numOfAnswers = 0;
	private ClientGUI cgui;
	
	public Messages(ClientGUI c) {
		cgui = c;
		init();
	}
	
	public void addMessage(String mes) {
		if ("Listing".equals(mes.split(" ")[0]) && !"Listing was successfully created.".equals(mes)) {
			answer.setEnabled(true);
			++numOfQuestions;
		}
		else if ("Answer sent.".equals(mes))
			++numOfAnswers;
		if (numOfQuestions == numOfAnswers)
			answer.setEnabled(false);
		messages.setText(messages.getText() + mes + 
				         "\n-------------------------\n");
	}
	
	private void init() {
		setTitle("Messages");
		setAlwaysOnTop(true);
		setVisible(false);
		setBounds(500, 400, 500, 300);
		JScrollPane scroll = new JScrollPane(messages);
		this.add(scroll);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3,1));
		JPanel txtPanel = new JPanel(new GridLayout(1,4));
		txtPanel.add(new JLabel("SubID:"));
		txtPanel.add(subID);
		txtPanel.add(new JLabel("ItemID:"));
		txtPanel.add(itemID);
		panel.add(txtPanel);
		panel.add(answer);
		panel.add(status);
		this.add(panel, BorderLayout.SOUTH);
		addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		    }});
		answer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					cgui.client.answer(Long.parseLong(subID.getText()), Long.parseLong(itemID.getText()));
					JButton source = (JButton) e.getSource();
                    source.setEnabled(false);
				}catch(Exception ex) {
					status.setText(ex.getMessage());
				}
			}
		});
		answer.setEnabled(false);
	}
}
