package client;

import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Serializable;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import misc.*;
import server.ServerIF;
import server.Server;

public class Client {
	public static final int DefaultPort = 4001;
	private static final String DefaultServer = "localhost";
	public ServerIF server;
	private String serverURL;
	private long id;
	public ClientInfoIF clientInfo;
	private int port = 0;
	private String name;
	public ClientGUI gui;
	public ClientCheck checker;
	public LinkedList<Item> items = new LinkedList<>();
	public LinkedList<Item> sold = new LinkedList<>();
	public LinkedList<Item> bought = new LinkedList<>();
	
	public Client (ClientGUI cg) {
		this(DefaultServer, DefaultPort, cg);
	}
	
	public Client(String url, int port2, ClientGUI cg) {
		serverURL = url;
		port = port2;
		gui = cg;
	}
	
	public void end (){
		try {
			checker.end();
			saveItems();
			saveBoughtItems(bought);
			saveSoldItems(sold);
		} catch (Exception e) {
		}
	}
	
	public void makeConnection() throws Exception {
		String url = "//" + serverURL + ":" + port + "/Server";
		try {
			gui.status.setText("Connecting...");
			server = (ServerIF) Naming.lookup(url);
			loadItems();
			checker = new ClientCheck(this,server.getTimeX());
		} catch (Exception e){
			System.out.println(e.getMessage());
			throw new Exception("Connection failed. Server isn't at " + url);
		}
	}
	
	public void loadItems() {
		File file = new File("client.txt");
		if (file.exists()) {
			try {
				BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
				String s;
				while((s = in.readLine())!=null){
					int id = Integer.parseInt(s);
					Item item = server.getItem(id, false);
					if (item!=null) {
						items.add(item);
					}
				}
				in.close();
			} catch (Exception e) {
				
			}
		}
	}
	
	public void saveItems() {
		File file = new File("client.txt");
		if (file.exists()) file.delete();
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < items.size(); i++){
				out.write((int) items.get(i).getID());
				out.newLine();
			}
			out.flush();
			out.close();
		} catch (Exception e) {
		}
	}
	
	public void saveBoughtItems(LinkedList<Item> bought) {
		File file = new File("MyBought.txt");
		if (file.exists()) file.delete();
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < bought.size(); i++){
				out.write(bought.get(i).toString());
				out.newLine();
			}
			out.flush();
			out.close();
		} catch (Exception e) {
		}
	}
	
	public void saveSoldItems(LinkedList<Item> sold) {
		File file = new File("MySold.txt");
		if (file.exists()) file.delete();
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < sold.size(); i++){
				out.write(sold.get(i).toString());
				out.newLine();
			}
			out.flush();
			out.close();
		} catch (Exception e) {
		}
	}
	
	public ClientInfoIF login(String name, String password) {
		try {
			return server.login(name, password);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ClientInfoIF signup(String name, String password, int funds) { // PRETPLATA -- OK
		try {
			return server.signup(name, password, funds);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public LinkedList<Item> getAllListings() {
		try {
			return server.getAllItems();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void createListingFile(File file) throws Exception { 
		Item item = new Item(file);
		item.setSeller(clientInfo);
		long id = server.addItem(item);
		item.setID(id);
		items.add(item);
		clientInfo.addListing(item);
		saveItems();
		gui.myListings.dlm.addElement(item.toString());
	}
	
	public void createListingParam(String nm, String descr, String pr, String t) throws Exception { 
		Item item = new Item(nm, descr, pr, t);
		item.setSeller(clientInfo);
		long id = server.addItem(item);
		item.setID(id);
		items.add(item);
		clientInfo.addListing(item);
		saveItems();
		gui.myListings.dlm.addElement(item.toString());
	}
	
	public void removeListing(long itemID) throws Exception { 
		boolean ret = server.removeItem(itemID, id);
		if (!ret) 
			throw new Exception("Canceling of a listing failed.");
		for (int i = 0; i < items.size(); i++){
			if (itemID == items.get(i).getID()) {
					items.remove(i);
					clientInfo.removeListing(itemID);
					break;
			}
		}		
	}
	
	public void makeBid(long itemID, int offer) throws Exception { 
		Item item = server.getItem(itemID, false);
		if (item.getSeller().getID() == id)
			throw new Exception("You can't bid on your own listing.");
		server.addBid(id,itemID,offer);
		gui.dlm.addElement(item.toString());
	}
	
	public void removeBid(long itemID) throws Exception { 
		boolean ret = server.removeBid(itemID, id);
		if (!ret)
			throw new Exception("You can't remove a bid.");
		clientInfo.removeBidItem(itemID);
	}
	
	public void makeWish(long itemID) throws Exception {
		try {
			LinkedList<Item> list = clientInfo.getBidItems();
			for(int i=0;i<list.size();i++)
				if (list.get(i).getID() == itemID)
					return;
			Item item = server.getItem(itemID, false);
			clientInfo.addToWishlist(item);
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}
	}
	
	public void removeWish(long itemID) throws Exception {
		try {
			clientInfo.removeFromWishlist(itemID);
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}
	}
	
	public synchronized void updateBidItems() throws Exception { 
		LinkedList<Item> bidItems;
		try {
			bidItems = clientInfo.getBidItems();
			gui.dlm.removeAllElements();
			for(int i=0;i<bidItems.size();i++) {
				Item item = bidItems.get(i);
				String newStr = "ID: " + item.getID() + " N: " + item.getName() + " D: " + item.getDescription() + " P: " + item.getPrice() + " T: " + (item.getTime() - item.getTimeElapsed()) + "s";
				gui.dlm.addElement(newStr);
			}
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}	
	}
	
	public synchronized void updateBoughtItems() throws Exception { 
		LinkedList<Item> boughtItems;
		try {
			boughtItems = clientInfo.getBoughtItems();
			bought = boughtItems;
			gui.purchases.dlm.removeAllElements();
			for(int i=0;i<boughtItems.size();i++) {
				String newStr = boughtItems.get(i).toString();
				gui.purchases.dlm.addElement(newStr);
			}
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}	
	}
	
	public synchronized void updateSoldItems() throws Exception { 
		LinkedList<Item> soldItems;
		try {
			soldItems = clientInfo.getSoldItems();
			sold = soldItems;
			gui.sold.dlm.removeAllElements();
			for(int i=0;i<soldItems.size();i++) {
					String newStr = soldItems.get(i).toString();
					gui.sold.dlm.addElement(newStr);
			}
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}	
	}
	
	public synchronized void updateWishlist() throws Exception { 
		LinkedList<Item> wishlist;
		try {
			wishlist = clientInfo.getWishlist();
			gui.wishlist.dlm.removeAllElements();
			for(int i=0;i<wishlist.size();i++) {
					String newStr = wishlist.get(i).toString();
					gui.wishlist.dlm.addElement(newStr);
			}
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}	
	}
	
	public synchronized void updateMyListings() throws Exception { 
		LinkedList<Item> myListings;
		try {
			myListings = clientInfo.getMyListings();
			gui.myListings.dlm.removeAllElements();
			for(int i=0;i<myListings.size();i++) {
					String newStr = myListings.get(i).toString();
					gui.myListings.dlm.addElement(newStr);
			}
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}	
	}
	
	public synchronized void updateMessages() throws Exception { 
		LinkedList<Message> messages;
		try {
			messages = clientInfo.getMessages();
			gui.messages.messages.setText("");
			gui.messages.numOfAnswers = 0;
			gui.messages.numOfQuestions = 0;
			for(int i=0;i<messages.size();i++) {
					String newStr = messages.get(i).content();
					gui.messages.addMessage(newStr);
			}
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		} 	
	}
	
	public synchronized void updateFunds() throws Exception {
		try {
			long funds = clientInfo.getSum();
			gui.funds.setText("" + funds);
		} catch (RemoteException e) {
			throw new Exception("Server unavailable");
		}	
	}
	
	public void answer(long subserverID, long itemID) throws Exception {
		try {
			if (server.getSubserver(subserverID).isAvailable()) {
				server.getSubserver(subserverID).setInterested(itemID, true);
			}
			clientInfo.addMessage(new Message("Answer sent."));
		} catch (Exception e) {
			throw new Exception("You entered either wrong subserverID or itemID");
		}
	}
	
	public void setInfo(ClientInfoIF cinfo) {
		clientInfo = cinfo;
	}
	
	public void  setID(long id) {
		this.id = id;
	}
	
	public long getID() {
		return id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public int getPort() {
		return port;
	}
	
	public void setPort(int port) {
		this.port = port;
	}
	
	public String getServerURL() {
		return serverURL;
	}
	
	public void setServerURL(String serverURL) {
		this.serverURL = serverURL;
	}
	
	public String Description() throws RemoteException {
		return "ID:  " + id + " NAME: " + name ;
	}
}