package client;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;

import misc.BankAccount;
import misc.Item;
import misc.Message;

public class ClientInfo extends UnicastRemoteObject implements ClientInfoIF {

	private long id;
	private String name;
	private String password;
	private BankAccount bankAccount;
	private LinkedList<Message> messages = new LinkedList<>();
	private LinkedList<Item> soldItems = new LinkedList<>();
	private LinkedList<Item> boughtItems = new LinkedList<>();
	private LinkedList<Item> listings = new LinkedList<>();
	private LinkedList<Item> bidItems = new LinkedList<>();
	private LinkedList<Item> wishlist = new LinkedList<>();
	
	public ClientInfo(String n, String p, int m) throws RemoteException {
		name = n;
		password = p;
		bankAccount = new BankAccount(m);
	}
	
	public void setID(long ID) throws RemoteException {
		id = ID;
	}
	
	public long getID() throws RemoteException {
		return id;
	}
	
	public String getName() throws RemoteException {
		return name;
	}
	
	public String getPassword() throws RemoteException {
		return password;
	}
	
	public synchronized void addFunds(long m) throws RemoteException {
		bankAccount.add(m);
	}
	
	public synchronized void removeFunds(long m) throws RemoteException {
		bankAccount.sub(m);
	}
	
	public synchronized long getSum() throws RemoteException {
		return bankAccount.getSum();
	}
	
	public synchronized void addMessage(Message mes) throws RemoteException {
		messages.add(mes);
	}
	
	public synchronized LinkedList<Message> getMessages() throws RemoteException  {
		LinkedList<Message> msg = new LinkedList<>();
		for(int i = 0;i<messages.size();i++)
			msg.add(messages.get(i));
		return msg;	
	}
	
	public String Description() throws RemoteException {
		return "ID:  " + id + " USERNAME: " + name;
	}

	@Override
	public synchronized void addBoughtItem(Item item) throws RemoteException {
		boughtItems.add(item);
	}

	@Override
	public synchronized void addSoldItem(Item item) throws RemoteException {
		soldItems.add(item);
	}

	@Override
	public synchronized void update(long itemID, long curPrice, long timeElapsed) throws RemoteException {
		for(int i=0;i<bidItems.size();i++) {
			if (bidItems.get(i).getID()==itemID) {
				bidItems.get(i).setPrice(curPrice);
				bidItems.get(i).setTimeElapsed(timeElapsed);
			}
		}
		for(int i=0;i<wishlist.size();i++) {
			if (wishlist.get(i).getID()==itemID) {
				wishlist.get(i).setPrice(curPrice);
				wishlist.get(i).setTimeElapsed(timeElapsed);
			}
		}
		
		for(int i=0;i<listings.size();i++) {
			if (listings.get(i).getID()==itemID) {
				listings.get(i).setPrice(curPrice);
				listings.get(i).setTimeElapsed(timeElapsed);
			}
		}	
	}

	@Override
	public synchronized void addListing(Item item) throws RemoteException {
		listings.add(item);
	}

	@Override
	public synchronized void addBidItem(Item item) throws RemoteException {
		bidItems.add(item);
	}

	@Override
	public synchronized void removeBidItem(long itemID) throws RemoteException {
		for(int i=0;i<bidItems.size();i++)
			if (bidItems.get(i).getID() == itemID) {
				bidItems.remove(i);
				return;
			}		
	}

	@Override
	public synchronized void removeListing(long itemID) throws RemoteException {
		for(int i=0;i<listings.size();i++)
			if (listings.get(i).getID() == itemID) {
				listings.remove(i);
				return;
			}		
	}

	@Override
	public synchronized LinkedList<Item> getBidItems() throws RemoteException {
		LinkedList<Item> list = new LinkedList<>();
		for(int i=0;i<bidItems.size();i++)
			list.add(bidItems.get(i));
		return list;	
	}

	@Override
	public synchronized LinkedList<Item> getBoughtItems() throws RemoteException {
		return boughtItems;
	}

	@Override
	public synchronized LinkedList<Item> getSoldItems() throws RemoteException {
		return soldItems;
	}

	@Override
	public synchronized void addToWishlist(Item item) throws RemoteException {
		wishlist.add(item);
	}

	@Override
	public synchronized void removeFromWishlist(long itemID) throws RemoteException {
		for(int i=0;i<wishlist.size();i++)
			if (wishlist.get(i).getID() == itemID) {
				wishlist.remove(i);
				return;
			}		
	}

	@Override
	public synchronized LinkedList<Item> getMyListings() throws RemoteException {
		LinkedList<Item> list = new LinkedList<>();
		for(int i=0;i<listings.size();i++)
			list.add(listings.get(i));
		return list;	
	}

	@Override
	public synchronized LinkedList<Item> getWishlist() throws RemoteException {
		LinkedList<Item> list = new LinkedList<>();
		for(int i=0;i<wishlist.size();i++)
			list.add(wishlist.get(i));
		return list;	
	}
}
