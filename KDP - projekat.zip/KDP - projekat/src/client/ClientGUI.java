package client;

import javax.swing.*;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.rmi.RemoteException;

public class ClientGUI extends JFrame implements ActionListener {
	private static final long serialVersionUID = 7795630780419002949L;
	private JToolBar messageBar = new JToolBar ();
	private Dimension dimenzijeProzora = new Dimension(600, 400);
	public JButton addItemFile = new JButton("Create Listing(File)");
	public JButton addItemParam = new JButton("Create Listing(Parameters)");
	public JButton removeItem = new JButton("Remove Listing");
	public JButton bid = new JButton("Bid");
	public JButton wish = new JButton("Add To Wishlist");
	public JButton removeBid = new JButton("Remove Bid");
	public JButton unwish = new JButton("Remove From Wishlist");
	public JButton showListings = new JButton("All Listings");
	public JButton showMyListings = new JButton("My Listings");
	public JButton showWishlist = new JButton("Wishlist");
	public JButton showMessages = new JButton("My Messages");
	public JButton boughtItems = new JButton("Bought Items");
	public JButton soldItems = new JButton("Sold Items");
	public JButton exitButton = new JButton ("Exit");
	public DefaultListModel<String> dlm = new DefaultListModel<String>();
	public JList<String> bidItems = new JList<>(dlm);
	public JTextArea status = new JTextArea();
	public JTextField name = new JTextField();
	public JTextField desc = new JTextField();
	public JTextField time = new JTextField();
	public JTextField price = new JTextField();
	public JTextField itemID = new JTextField();
	public JTextField priceBid = new JTextField();
	public JLabel funds = new JLabel();
	public JTextField rlID = new JTextField();
	public JTextField rbID = new JTextField();
	public JTextField myID = new JTextField();
	public JTextField myName = new JTextField();
	public JFileChooser fc = new JFileChooser();
	public Connect connect = new Connect(this);
	public Client client;
	public Messages messages = new Messages(this);
	public Listings listings;
	public MyListings myListings = new MyListings();
	public Purchases purchases = new Purchases();
	public Wishlist wishlist = new Wishlist();
	public Sold sold = new Sold();
	
	
	public ClientGUI () {
		client = new Client(this);
		listings = new Listings(client);
		init();
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == addItemFile) {
				int returnVal = fc.showOpenDialog(this);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					client.createListingFile(file);
				}
			}
		} catch (Exception e1) {
			status.setText(e1.getMessage());
		}
	}
	
	private void init() {
		setTitle("Client");
		setBounds(0, 400, 700, 200);
		this.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
	    	client.end();
	    	System.exit(0);
	    }});
		setPreferredSize(dimenzijeProzora);
		setMinimumSize(dimenzijeProzora);
		setResizable(false);
		JPanel panel = new JPanel();
		fc.setCurrentDirectory(new File("."));
		panel.setLayout(new GridLayout(2,3));
		JPanel selling = new JPanel(new GridLayout(10,1));
		JPanel bidding = new JPanel(new GridLayout(8,1));
		JPanel remSell = new JPanel(new GridLayout(3,1));
		JPanel remBid = new JPanel(new GridLayout(4,1));
		JPanel options = new JPanel(new GridLayout(7,1));
		selling.add(new JLabel("Name"));
		selling.add(name);
		selling.add(new JLabel("Description"));
		selling.add(desc);
		selling.add(new JLabel("Price"));
		selling.add(price);
		selling.add(new JLabel("Auction Time[s]"));
		selling.add(time);
		selling.add(addItemParam);
		selling.add(addItemFile);
		selling.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		bidding.add(new JLabel("ItemID"));
		bidding.add(itemID);
		bidding.add(new JLabel("Offer"));
		bidding.add(priceBid);
		bidding.add(new JLabel("Funds"));
		bidding.add(funds);
		bidding.add(bid);
		bidding.add(wish);
		bidding.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		remSell.add(new JLabel("ItemID"));
		remSell.add(rlID);
		remSell.add(removeItem);
		remSell.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		remBid.add(new JLabel("ItemID"));
		remBid.add(rbID);
		remBid.add(removeBid);
		remBid.add(unwish);
		remBid.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		options.add(showListings);
		options.add(showMyListings);
		options.add(showWishlist);
		options.add(showMessages);
		options.add(boughtItems);
		options.add(soldItems);
		options.add(exitButton);
		options.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		panel.add(selling);
		panel.add(bidding);
		bidItems.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		JScrollPane scroll = new JScrollPane(bidItems);
		panel.add(scroll);
		panel.add(remSell);
		panel.add(remBid);
		panel.add(options);
		JPanel southPanel = new JPanel(new GridLayout(2,1));
		southPanel.add(new JLabel("Status:"));
		southPanel.add(status);
		this.add(panel);
		this.add(southPanel,BorderLayout.SOUTH);
		exitButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				client.end();
		    	System.exit(0);			
			}	
		});
		addItemFile.addActionListener(this);
		addItemParam.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String Name = name.getText();
				String Desc = desc.getText();
				String Price = price.getText();
				String Time = time.getText();
				try {
					client.createListingParam(Name, Desc, Price, Time);
				} catch (Exception e1) {
					status.setText(e1.getMessage());
				}
			}
		});
		bid.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					client.makeBid(Long.parseLong(itemID.getText()), Integer.parseInt(priceBid.getText()));
				} catch (Exception e1) {
					status.setText(e1.getMessage());
				}
				
			}
		});
		wish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					client.makeWish(Integer.parseInt(itemID.getText()));
				} catch (NumberFormatException e1) {
					e1.printStackTrace();
				} catch (Exception e1) {
					status.setText(e1.getMessage());
				}
			}
		});
		unwish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					client.removeWish(Integer.parseInt(itemID.getText()));
				} catch (NumberFormatException e1) {
					e1.printStackTrace();
				} catch (Exception e1) {
					status.setText(e1.getMessage());
				}
			}
		});
		removeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					client.removeListing(Integer.parseInt(rlID.getText()));
				} catch (Exception e1) {
					status.setText(e1.getMessage());
				}
			}
		});
		removeBid.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					client.removeBid(Long.parseLong(rbID.getText()));
				} catch (Exception e1) {
					status.setText(e1.getMessage());
				}
				
			}
		});
		showListings.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				listings.update(client.getAllListings());
				listings.setVisible(true);
				
			}
		});
		showMyListings.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				myListings.setVisible(true);
			}
		});
		showWishlist.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				wishlist.setVisible(true);
			}
		});
		boughtItems.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				purchases.setVisible(true);
			}
		});
		soldItems.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				sold.setVisible(true);
			}
		});
		showMessages.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				messages.setVisible(true);
			}
		});
	}
	
	
	public static void main(String[] args) {
		ClientGUI gui1 = new ClientGUI();
	}
}
