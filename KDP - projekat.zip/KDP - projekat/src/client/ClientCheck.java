package client;

import server.ServerIF;

public class ClientCheck implements Runnable {
	private Client client = null;
	private Thread myThread = null;
	private boolean theEND = false;
	private long x;
	
	public ClientCheck (Client cl, long time) {
		client = cl;
		x = time;
	}
	
	public void run() {
		while(!theEND){
			try {
				String ip = java.net.InetAddress.getLocalHost().getHostAddress();
				client.updateMessages();
				client.updateBidItems();
				client.updateBoughtItems();
				client.updateSoldItems();
				client.updateWishlist();
				client.updateMyListings();
				client.updateFunds();
				client.server.ping(ip);
				Thread.sleep(x*1000);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				theEND = true;
				client.gui.status.setText("Server disconnect");
				client.gui.setEnabled(false);
				client.gui.connect = new Connect(client.gui);
			}
		}
	}
	public void start () {
		if (myThread == null){
			myThread = new Thread(this, "Client Checker");
			myThread.start();
		}
	}
	public void stop () {
		Thread stopThread = myThread;
		myThread = null;
		stopThread.interrupt();
	}
	public void end () {
		theEND = true;
	}
}