package client;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import misc.Item;

public class MyListings extends JDialog {

	public DefaultListModel<String> dlm = new DefaultListModel<String>();
	public JList<String> myListings = new JList<>(dlm);
	
	public MyListings() {
		init();
	}
	
	private void init() {
		setTitle("My Listings");
		setAlwaysOnTop(true);
		setVisible(false);
		setBounds(500, 400, 800, 300);
		JScrollPane scroll = new JScrollPane(myListings);
		add(scroll);
		addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		    }});
	}
}