package client;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Connect extends JDialog {
	private static final long serialVersionUID = 7568089158028925390L;
	private Dimension dimenzijeProzora = new Dimension(200, 200);
	private JTextField portOfServer = new JTextField();
	private JTextField ipOfServer = new JTextField();
	public JButton login = new JButton ("Log In");
	public JButton signup = new JButton ("Sign Up");
	public ClientGUI win = null;
	public JTextField myName = new JTextField();
	public JTextField myPassword = new JPasswordField();
	public JTextField myMoney = new JTextField("200");
	public JTextArea status = new JTextArea();
	
	public Connect (ClientGUI cg) {
		win = cg;
		init();
		setVisible(true);
	}
	private void init() {
		setAlwaysOnTop(true);
		win.setEnabled(false);
		setTitle("Connect");
		setBounds(500, 400, 400, 200);
		this.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
	    	System.exit(0);
	    }});
		setPreferredSize(dimenzijeProzora);
		setMinimumSize(dimenzijeProzora);
		setResizable(false);
		JPanel panel = new JPanel(new GridLayout(6,1));
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel info = new JPanel(new GridLayout(6,1));
		info.add(new JLabel("Client Username"));
		info.add(myName);
		info.add(new JLabel("Client Password"));
		info.add(myPassword);
		info.add(new JLabel("Client Funds"));
		info.add(myMoney);
		panel.add(new JLabel("Server IP : "));
		ipOfServer.addFocusListener(new Fokuser());
		panel.add(ipOfServer);
		panel.add(new JLabel("Port : "));
		portOfServer.setText(String.valueOf(Client.DefaultPort));
		portOfServer.setPreferredSize(new Dimension(100, 20));
		panel.add(portOfServer);
		login.addActionListener(new Starter());
		signup.addActionListener(new Starter());
		panel.add(login);
		panel.add(signup);
		JPanel northPanel = new JPanel(new GridLayout(1,2));
		northPanel.add(panel);
		northPanel.add(info);
		JPanel southPanel = new JPanel(new GridLayout(2,1));
		southPanel.add(new JLabel("Status:"));
		status.setCaretColor(Color.RED);
		southPanel.add(status);
		this.add(northPanel);
		this.add(southPanel,BorderLayout.SOUTH);
	}
	class Fokuser implements FocusListener {
		public void focusGained(FocusEvent arg0) {
			ipOfServer.setBackground(new Color(255, 255, 255));			
		}

		public void focusLost(FocusEvent arg0) {
						
		}	
	}
	class Starter implements ActionListener{
		public boolean isIP (String ip) {
			try {
		        if (ip == null || ip.isEmpty()) {
		            return false;
		        }

		        String[] parts = ip.split( "\\." );
		        if (parts.length != 4) {
		            return false;
		        }

		        for (String s : parts) {
		            int i = Integer.parseInt( s );
		            if ((i < 0) || (i > 255)) {
		                return false;
		            }
		        }
		        if (ip.endsWith(".")) {
		            return false;
		        }

		        return true;
		    } catch (NumberFormatException nfe) {
		        return false;
		    }
		}
		public void actionPerformed(ActionEvent e){
			try {
				if(isIP(ipOfServer.getText())) {
					win.client.setServerURL(ipOfServer.getText());
					win.client.setPort(Integer.parseInt(portOfServer.getText()));
					String username = myName.getText();
					String password = myPassword.getText();
					int funds = Integer.parseInt(myMoney.getText());
					win.client.makeConnection();
					ClientInfoIF cinfo = null;
					
					if (e.getSource() == login) {
						cinfo = win.client.login(username,password);
						if(cinfo == null) {
							win.client.end();
							status.setText("Your username or password is wrong or your account doesn't exist.");
							return;
						}
					}
					
					if (e.getSource() == signup) {
						cinfo = win.client.signup(username,password,funds);
						if(cinfo == null) {
							win.client.end();
							status.setText("Account with this username already exists.");
							return;
						}
					}
					win.status.setText("Connected on " + "//" + ipOfServer.getText() + ":" + Integer.parseInt(portOfServer.getText()) + "/Server");
					win.client.setID(cinfo.getID());
					win.client.setInfo(cinfo);
					win.setTitle(cinfo.Description());
					win.funds.setText(funds + "");
					win.client.checker.start();
					win.setEnabled(true);
					dispose();
				}
			} catch (Exception e1) {
				status.setText(e1.getMessage());
			}
		}
	}
}