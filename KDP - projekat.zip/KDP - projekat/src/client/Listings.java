package client;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JTextField;

import misc.Item;

public class Listings extends JDialog {

	private DefaultListModel<String> dlm = new DefaultListModel<String>();
	private JList<String> listings = new JList<>(dlm);
	private JButton refresh = new JButton("Refresh");
	private Client client;
	
	public Listings(Client c) {
		client = c;
		init();
	}
	
	private void init() {
		setTitle("All Listings");
		setAlwaysOnTop(true);
		setVisible(false);
		setBounds(500, 400, 800, 300);
		add(listings);
		add(refresh,BorderLayout.SOUTH);
		addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		    }});
		refresh.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				update(client.getAllListings());
			}
		});
	}
	
	public void update(LinkedList<Item> list) {
		dlm.removeAllElements();
		for(int i=0;i<list.size();i++)
			dlm.addElement(list.get(i).toString());
	}
}