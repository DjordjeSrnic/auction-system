package client;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.LinkedList;

import misc.Item;
import misc.Message;

public interface ClientInfoIF extends Remote {

	void setID(long ID) throws RemoteException;
	
	long getID() throws RemoteException;
	
	String getName() throws RemoteException;
	
	String getPassword() throws RemoteException;
	
	void addFunds(long m) throws RemoteException;
	
	void removeFunds(long m) throws RemoteException;
	
	long getSum() throws RemoteException;
	
	void addMessage(Message mes) throws RemoteException;
	
	LinkedList<Message> getMessages() throws RemoteException;
	
	String Description() throws RemoteException;
	
	void addBoughtItem(Item item) throws RemoteException;
	
	void addToWishlist(Item item) throws RemoteException;
	
	void addSoldItem(Item item) throws RemoteException;
	
	void addListing(Item item) throws RemoteException;
	
	void addBidItem(Item item) throws RemoteException;
	
	void removeBidItem(long l) throws RemoteException;
	
	LinkedList<Item> getBidItems() throws RemoteException;
	
	LinkedList<Item> getBoughtItems() throws RemoteException;
	
	LinkedList<Item> getSoldItems() throws RemoteException;
	
	LinkedList<Item> getMyListings() throws RemoteException;
	
	LinkedList<Item> getWishlist() throws RemoteException;
	
	void removeListing(long l) throws RemoteException;
	
	void removeFromWishlist(long itemID) throws RemoteException;
	
	void update(long itemID, long curPrice, long timeRemaining) throws RemoteException;
}
