package client;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import misc.Item;

public class Sold extends JDialog {

	public DefaultListModel<String> dlm = new DefaultListModel<String>();
	private JList<String> sold = new JList<>(dlm);
	
	public Sold() {
		init();
	}
	
	private void init() {
		setTitle("Sold Items");
		setAlwaysOnTop(true);
		setVisible(false);
		setBounds(500, 400, 800, 300);
		JScrollPane scroll = new JScrollPane(sold);
		add(scroll);
		addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		    }});
	}
}